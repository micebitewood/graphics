/*
	Assinment 5
	John Mu
	jm4911@nyu.edu

	This is a scene of a cube rotating at the center, with background moving.
*/
public class MyMISApplet extends MISApplet {

	//for saving the time
    double t = 0;
	
	//this is a cube
	Geometry world = new Geometry();
	Geometry cube = world.add();
	
	//for saving the data in cube, using vertices = getVertices() and faces = getFaces()
	double[][] vertices;
	int[][] faces;
	
	//for saving the points after projection
	int[][] point = new int[4][2];

	//for saving the points after transformation
	double[][] trans = new double[4][3];
	
	//for projecting the points in vertices to point
	Projection projection = new Projection();

    public void initFrame(double time) {
	
		//save the time in t
		t = 3 * time;
	   
    }
    public void setPixel(int x, int y, int rgb[]) {
	
		//play around, I'm sorry that might make you dizzy
		double r = Math.sqrt((double)( (x - W / 2) * (x - W / 2) + (y - H / 2) * (y - H / 2)));
		for(int i = 0; i < 3; i++)
		{
			rgb[i] = (int) (50 * (Math.sin(t) + 2) * (Math.sin(t + r) + 1 + i));
		}
		
    }
	
	public void drawFace()
	{
		//for saving a single face
		int face[];
		
		for(int i = 0; i < faces.length; i++)
		{
			face = faces[i];
			
			//Projection
			for(int j = 0; j < face.length; j++)
			{
				cube.getMatrix().transform(vertices[face[j]], trans[j]);
				projection.project(trans[j], point[j]);
			}
			
			double area = 0;
			
			//calculate the area
			for(int j = 0; j < face.length; j++)
				area += (point[j][0] - point[(j + 1) % face.length][0]) * (point[j][1] + point[(j + 1) % face.length][1]) / 2.0;
			//if it's larger than zero, it means the face is in the back
			if(area > 0)
				continue;
			
			//m stores the three vertices from top to bottom, m[0]:A, m[1]:B, m[2]:C
			int[] m = {0, 0, 0};
			
			//D stores the vertice of D, and BD divides the triangle into to pieces
			int[] D = {0, 0};
			
			//First, let's deal with the triangle point[0], point[1], point[2]
			//If there is a D existing
			if(Triangle.split(point, m, D, 0, 1, 2))
			{
				draw(point[m[0]], point[m[1]], D, true);//A, B, D, triangle up
				draw(point[m[1]], D, point[m[2]], false);//B, D, C, triangle down
			}
			
			//if yA == yB or yB == yC
			//if yA == yB, it's a triangle down
			//if yB == yC, it's a triangle up
			else
				draw(point[m[0]], point[m[1]], point[m[2]], point[m[1]][1] == point[m[2]][1]);
				
			//Second, let's deal with the triangle point[2], point[3], point[0]
			//If there is a D existing
			if(Triangle.split(point, m, D, 2, 3, 0))
			{
				draw(point[m[0]], point[m[1]], D, true);//A, B, D, triangle up
				draw(point[m[1]], D, point[m[2]], false);//B, D, C, triangle down
			}
			
			//if yA == yB or yB == yC
			//if yA == yB, it's a triangle down
			//if yB == yC, it's a triangle up
			else
				draw(point[m[0]], point[m[1]], point[m[2]], point[m[1]][1] == point[m[2]][1]);
		}
	}
	
	/*
		if(b): two cases
			A
		   / \
		  /   \
		 /	   \
		B-------C
	-------or-------
			A
		   / \
		  /   \
		 /	   \
		C-------B
--------------------------------------------------------------
		if(!b): two cases
		A-------B
		 \	   /
		  \   /
		   \ /
			C
	--------or--------
		B-------A
		 \     /
		  \   /
		   \ /
			C
	*/
	public void draw(int[] A, int[] B, int[] C, boolean b)
	{
		if(b)
		{
			int[] XL = {A[0], B[0]};//XLT = xA, XLB = xB
			int[] XR = {A[0], C[0]};//XRT = xA, XRB = xC
			if(B[0] > C[0])//xB > xC
			{
				XL[1] = C[0];//XLB = xC
				XR[1] = B[0];//XRB = xB
			}
			drawTriangle(XL, XR, A[1], C[1]);//XLT, XLB, XRT, XRB, yT, yB
		}
		else
		{
			int[] XL = {A[0], C[0]};//XLT = xA, XLB = xB
			int[] XR = {B[0], C[0]};//XRT = xA, XRB = xC
			if(A[0] > B[0])//xA > xB
			{
				XL[0] = B[0];//XLB = xC
				XR[0] = A[0];//XRB = xB
			}
			drawTriangle(XL, XR, A[1], C[1]);//XLT, XLB, XRT, XRB, yT, yB
		}
	}
	
	//XLT = XL[0], XLB = XL[1], XRT = XR[0], XRB = XR[1]
	public void drawTriangle(int[] XL, int[] XR, int yT, int yB)
	{
		for(int y = yT; y <= yB; y++)
		{
			double t = (y - yT) * 1.0 / (yB - yT);
			//xL = XLT + t * (XLB - XLT)
			int xL = (int) (XL[0] + t * (XL[1] - XL[0]));
			//xR = XRT + t * (XRB - XRT)
			int xR = (int) (XR[0] + t * (XR[1] - XR[0]));
			
			//paint!
			pix[y * W + xL] = pack(0, 0, 0);
			pix[y * W + xR] = pack(0, 0, 0);
			for(int x = xL + 1; x < xR; x++)
				pix[y * W + x] = pack(255, 0, 0);
		}
	}
	
	private int rgb[] = new int[3];
	public void computeImage(double time)
	{
		initFrame(time);
		
		cube.cube();
		cube.getMatrix().identity().rotateY(time).rotateX(time);
		
		projection.setWidth(W);
		projection.setHeight(H);
		projection.setFL(10);
		
		vertices = cube.getVertices();
		faces = cube.getFaces();

		//paint the background
		for(int y = 0; y < H; y++)
			for(int x = 0; x < W; x++)
			{
				setPixel(x, y, rgb);
				pix[x + y * W] = pack(rgb[0], rgb[1], rgb[2]);
			}
		//paint the cube
		drawFace();
	}
}
